import React, {useMemo, useState, useEffect} from 'react';
import {createRoot} from 'react-dom/client';
import {MapContainer, TileLayer, Polyline, CircleMarker, Popup, Tooltip, useMap} from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import './styles.css';
import demoData from './data/journey_demo_data.json';
import placeAliases from './data/place_aliases.json';

const WALK_SPEED = 12;
const MAP_CENTER = [23.10, 72.62];
const MODE_COLORS = {walk:'#68756f', bus:'#e07a32', metro:'#0f766e'};
const PLACE_FALLBACK = placeAliases.map(p => [p.name,p.lat,p.lon]);
const MAP_PLACES = placeAliases;

function hav(a,b){const x=(a.lat-b.lat)*111,y=(a.lon-b.lon)*102;return Math.sqrt(x*x+y*y)}
function norm(s=''){return s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,' ').trim()}
function fmt(m){m=Math.round(m);return m<60?`${m} min`:`${Math.floor(m/60)}h ${m%60?m%60+'m':''}`}
function edgeWait(data,e,lastRoute){if(e[3]==='walk'||lastRoute===e[5])return 0;if(e[3]==='metro')return 4;const h=data.headways?.[`${e[4]}|${e[5]}`]||20;return Math.min(25,Math.max(2,Math.round(h/2)))}
function levenshtein(a,b){if(a===b)return 0;if(!a)return b.length;if(!b)return a.length;let prev=Array.from({length:b.length+1},(_,i)=>i);for(let i=0;i<a.length;i++){const cur=[i+1];for(let j=0;j<b.length;j++)cur[j+1]=Math.min(cur[j]+1,prev[j+1]+1,prev[j]+(a[i]===b[j]?0:1));prev=cur}return prev[b.length]}
function tokenScore(q,name){const a=norm(q),b=norm(name);if(!a||!b)return 0;if(a===b)return 120;if(b.startsWith(a+' ')||a.startsWith(b+' '))return 92;if(b.includes(a)||a.includes(b))return 76;const qt=new Set(a.split(' ')),nt=new Set(b.split(' '));const overlap=[...qt].filter(x=>nt.has(x)).length;const fuzzy=Math.max(0,60-levenshtein(a,b)*4);return Math.max(overlap*18,fuzzy)}

function normalizeData(data){
  if(data.nodes && data.edges) return data;
  const nodes=(data.stops||[]).map((s,i)=>({id:s[0],name:s[1],lat:s[2],lon:s[3],kind:'bus',idx:i}));
  const metroCoords={'AMM_GNLU':[23.1878,72.6276],'AMM_INFOCITY':[23.1902,72.6350],'AMM_GIFT_CITY':[23.1630,72.6844]};
  const metroNodes=(data.metroStops||[]).map(s=>({id:s[0],name:s[1],lat:s[2]??metroCoords[s[0]]?.[0],lon:s[3]??metroCoords[s[0]]?.[1],kind:'metro',line:s[4]}));
  const all=[...nodes,...metroNodes],byIndex=nodes,edges=[];
  for(const e of (data.busEdges||[])){const a=byIndex[e[0]],b=byIndex[e[1]];if(a&&b)edges.push([a.id,b.id,e[2],'bus',e[3],e[4]]);}
  const metroLine=Object.fromEntries(metroNodes.map(n=>[n.id,n.line]));
  const lineIds=[...new Set(metroNodes.flatMap(n=>(n.line||'').split(';').filter(Boolean)))];
  for(const line of lineIds){const seq=metroNodes.filter(n=>(n.line||'').split(';').includes(line));for(let i=0;i<seq.length-1;i++){const a=seq[i],b=seq[i+1];const minutes=(Number.isFinite(a.lat)&&Number.isFinite(b.lat))?Math.max(2,Math.round(hav(a,b)*2.4)):4;edges.push([a.id,b.id,minutes,'metro',line,line],[b.id,a.id,minutes,'metro',line,line]);}}
  for(const e of (data.metroEdges||[])){const line=metroLine[e[0]]||'Metro';edges.push([e[0],e[1],e[2],'metro',line,line]);}
  const buses=nodes.filter(n=>Number.isFinite(n.lat)&&Number.isFinite(n.lon)),metros=metroNodes.filter(n=>Number.isFinite(n.lat)&&Number.isFinite(n.lon));
  for(const b of buses)for(const m of metros){const d=hav(b,m);if(d<=0.9){const mins=Math.max(1,Math.ceil(d/WALK_SPEED*60));edges.push([b.id,m.id,mins,'walk','WALK','walk'],[m.id,b.id,mins,'walk','WALK','walk']);}}
  return {...data,nodes:all,edges,places:PLACE_FALLBACK};
}

function createRouter(raw){
  const data=normalizeData(raw),N=data.nodes||[],E=data.edges||[],byId=Object.fromEntries(N.map(n=>[n.id,n]));
  const aliases=placeAliases.flatMap(p=>[p.name,...p.aliases].map(alias=>({alias,name:p.name,lat:p.lat,lon:p.lon,category:p.category,canonical:p})));
  function resolve(input,gps){
    const raw=String(input||'').trim();
    if(raw==='My current location'&&gps)return {name:raw,...gps};
    const q=norm(raw);if(!q)return null;
    const exactNode=N.find(n=>norm(n.name)===q||norm(n.name.replace(/\s+(metro\s+)?station$/i,''))===q);
    if(exactNode)return {name:exactNode.name,lat:exactNode.lat,lon:exactNode.lon,node:exactNode,match:'exact'};
    const exactAlias=aliases.find(a=>norm(a.alias)===q);
    if(exactAlias)return {...exactAlias,match:'alias'};
    let best=null,bs=0;
    for(const n of N){const sc=tokenScore(q,n.name);if(sc>bs){bs=sc;best={name:n.name,lat:n.lat,lon:n.lon,node:n,match:'fuzzy'}}}
    for(const a of aliases){const sc=tokenScore(q,a.alias);if(sc>bs){bs=sc;best={name:a.name,lat:a.lat,lon:a.lon,category:a.category,match:'fuzzy'}}}
    return bs>=42?best:null;
  }
  function suggestions(input,limit=6){
    const q=norm(input);if(!q)return [];
    const candidates=[];
    for(const p of placeAliases){const sc=Math.max(tokenScore(q,p.name),...p.aliases.map(a=>tokenScore(q,a)));if(sc>=24)candidates.push({name:p.name,lat:p.lat,lon:p.lon,category:p.category,score:sc});}
    for(const n of N){const sc=tokenScore(q,n.name);if(sc>=40)candidates.push({name:n.name,lat:n.lat,lon:n.lon,category:n.kind==='metro'?'Metro station':'Transit stop',node:n,score:sc});}
    const seen=new Set();return candidates.sort((a,b)=>b.score-a.score).filter(x=>{const k=norm(x.name);if(seen.has(k))return false;seen.add(k);return true}).slice(0,limit);
  }
  function nearestCandidates(pt,maxDist=4,limit=10){return N.map(n=>({node:n,dist:(n.lat==null||n.lon==null)?Infinity:hav(pt,n)})).filter(x=>Number.isFinite(x.dist)&&x.dist<=maxDist).sort((x,y)=>x.dist-y.dist).slice(0,limit)}
  function findRoutes(fromQ,toQ,pref,gps){
    const a=resolve(fromQ,gps),b=resolve(toQ,gps);if(!a||!b)return [];
    const sources=a.node?[{node:a.node,dist:0}]:nearestCandidates(a),targets=b.node?[{node:b.node,dist:0}]:nearestCandidates(b);if(!sources.length||!targets.length)return [];
    const targetAccess=new Map(targets.map(t=>[t.node.id,t.dist*WALK_SPEED])),adj=Object.fromEntries(N.map(n=>[n.id,[]]));for(const e of E)if(adj[e[0]])adj[e[0]].push(e);
    const results=[];
    for(const source of sources){
      const s=source.node,initial=source.dist*WALK_SPEED,dist=new Map(),prev=new Map(),pq=[[initial,s.id,null]];dist.set(s.id+'|',initial);let bestGoal=null;
      while(pq.length){pq.sort((x,y)=>x[0]-y[0]);const [cost,u,lastRoute]=pq.shift(),key=u+'|'+(lastRoute||'');if(cost>(dist.get(key)??Infinity)+1e-6)continue;const access=targetAccess.get(u);if(access!==undefined){const total=cost+access;if(!bestGoal||total<bestGoal.total)bestGoal={total,cost,u,lastRoute,access,key};}if(bestGoal&&cost>=bestGoal.total)continue;for(const e of (adj[u]||[])){const wait=edgeWait(data,e,lastRoute),nc=cost+e[2]+wait,nr=e[5]||lastRoute,nkey=e[1]+'|'+(nr||'');if(nc<(dist.get(nkey)??Infinity)){dist.set(nkey,nc);prev.set(nkey,[key,e]);pq.push([nc,e[1],nr]);}}}
      if(!bestGoal)continue;
      let key=bestGoal.key,edges=[];while(prev.has(key)){const [pk,e]=prev.get(key);edges.push(e);key=pk}edges.reverse();
      const accessLegs=[];
      if(initial>0)accessLegs.push({type:'walk',label:'Walk',route:'walk',mins:Math.max(1,Math.round(initial)),from:a.name,to:s.name,geometry:[[a.lat,a.lon],[s.lat,s.lon]],access:true});
      let grouped=[...accessLegs];
      for(const e of edges){const type=e[3],label=type==='metro'?'Metro':type==='walk'?'Walk':(e[4]==='AJL'?'BRTS':e[4]==='GTSL'?'GTSL':'AMTS'),route=e[5],last=grouped.at(-1),from=byId[e[0]],to=byId[e[1]],pointA=[from.lat,from.lon],pointB=[to.lat,to.lon];if(last&&last.type===type&&last.route===route){last.mins+=e[2];last.to=to.name;last.geometry.push(pointB);}else grouped.push({type,label,route,mins:e[2],from:from.name,to:to.name,geometry:[pointA,pointB]});}
      if(bestGoal.access>0){const target=byId[bestGoal.u];grouped.push({type:'walk',label:'Walk',route:'walk',mins:Math.max(1,Math.round(bestGoal.access)),from:target.name,to:b.name,geometry:[[target.lat,target.lon],[b.lat,b.lon]],access:true});}
      const walk=initial+bestGoal.access+edges.filter(e=>e[3]==='walk').reduce((sum,e)=>sum+e[2],0),transfers=Math.max(0,grouped.filter(x=>x.type!=='walk').length-1),score=bestGoal.total+(pref==='walk'?walk*1.8:pref==='transfer'?transfers*8:pref==='cheap'?transfers*3:0);
      results.push({score,total:Math.round(bestGoal.total),walk:Math.round(walk),transfers,legs:grouped,source:s.id,origin:{name:a.name,lat:a.lat,lon:a.lon},destination:{name:b.name,lat:b.lat,lon:b.lon}});
    }
    results.sort((x,y)=>x.score-y.score);const unique=[],seen=new Set();for(const r of results){const sig=r.legs.map(l=>`${l.type}:${l.route}:${l.from}>${l.to}`).join('|');if(!seen.has(sig)){seen.add(sig);unique.push(r)}if(unique.length===3)break}return unique;
  }
  return {findRoutes,suggestions,resolve,places:PLACE_FALLBACK,N};
}

function validPoint(p){return Array.isArray(p)&&p.length>=2&&Number.isFinite(Number(p[0]))&&Number.isFinite(Number(p[1]))?[Number(p[0]),Number(p[1])]:null}
function safeGeometry(geometry){return (geometry||[]).map(validPoint).filter(Boolean)}
function MapFit({route}){const map=useMap();useEffect(()=>{if(!route)return;const pts=route.legs.flatMap(l=>safeGeometry(l.geometry));if(pts.length>=2)map.fitBounds(pts,{padding:[30,30],maxZoom:15});},[route,map]);return null}
function JourneyMap({route}){
  const [selectedLeg,setSelectedLeg]=useState(null);
  const safeLegs=route?.legs.map(leg=>({...leg,geometry:safeGeometry(leg.geometry)})).filter(leg=>leg.geometry.length>=2)||[];
  const points=safeLegs.flatMap(l=>l.geometry);
  return <div className="map-card"><div className="map-head"><div><b>Journey map</b><span>{route?`${route.origin.name} → ${route.destination.name}`:'Choose a journey to visualize it'}</span></div>{route&&<div className="map-legend">{route.legs.filter((l,i,a)=>a.findIndex(x=>x.type===l.type)===i).map(l=><button key={l.type} className={selectedLeg===l.type?'active':''} onClick={()=>setSelectedLeg(selectedLeg===l.type?null:l.type)}><i style={{background:MODE_COLORS[l.type]}}></i>{l.label}</button>)}</div>}</div><MapContainer center={MAP_CENTER} zoom={11} scrollWheelZoom className="map"><TileLayer attribution='&copy; OpenStreetMap contributors' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"/><MapFit route={route}/>{MAP_PLACES.map(p=><CircleMarker key={p.name} center={[p.lat,p.lon]} radius={p.mapLabel?5:3.5} pathOptions={{color:'#fff',weight:1.5,fillColor:p.category==='locality'?'#0f766e':'#e07a32',fillOpacity:.95}}><Tooltip permanent={Boolean(p.mapLabel)} direction="right" offset={[7,0]} className="locality-tooltip">{p.name}</Tooltip><Popup><b>{p.name}</b><br/>{p.category||'Landmark'}<br/><small>Approximate reference location</small></Popup></CircleMarker>)}{route&&<>{safeLegs.map((leg,i)=><Polyline key={i} positions={leg.geometry} pathOptions={{color:MODE_COLORS[leg.type]||MODE_COLORS.walk,weight:selectedLeg&&selectedLeg!==leg.type?4:6,opacity:selectedLeg&&selectedLeg!==leg.type ? .3 : .9,dashArray:leg.type==='walk'?'7 8':undefined}}/>)}{validPoint([route.origin.lat,route.origin.lon])&&<CircleMarker center={validPoint([route.origin.lat,route.origin.lon])} radius={9} pathOptions={{color:'#0f766e',fillOpacity:1}}><Popup><b>Origin</b><br/>{route.origin.name}</Popup></CircleMarker>}{validPoint([route.destination.lat,route.destination.lon])&&<CircleMarker center={validPoint([route.destination.lat,route.destination.lon])} radius={9} pathOptions={{color:'#d65a3a',fillOpacity:1}}><Popup><b>Destination</b><br/>{route.destination.name}</Popup></CircleMarker>}{points.filter((p,i)=>i%12===0).slice(0,120).map((p,i)=><CircleMarker key={`p${i}`} center={p} radius={2.5} pathOptions={{color:'#fff',fillOpacity:.85,weight:1}}/> )}</>}</MapContainer></div>
}

function App(){
  const [data]=useState(demoData),[from,setFrom]=useState(''),[to,setTo]=useState(''),[pref,setPref]=useState('fast'),[results,setResults]=useState([]),[selected,setSelected]=useState(0),[status,setStatus]=useState('Choose an origin and destination'),[prompt,setPrompt]=useState(''),[insight,setInsight]=useState(''),[gps,setGps]=useState(null),[error,setError]=useState('');
  const router=useMemo(()=>createRouter(data),[data]),stats=data?.meta||{},selectedRoute=results[selected]||results[0]||null;
  const fromSuggestions=useMemo(()=>router.suggestions(from),[router,from]);
  const toSuggestions=useMemo(()=>router.suggestions(to),[router,to]);
  const run=(f=from,t=to,p=pref)=>{if(!f||!t){setResults([]);setStatus('Enter both locations or choose an example');return}const r=router.findRoutes(f,t,p,gps);setResults(r);setSelected(0);setStatus(r.length?`${r.length} option${r.length===1?'':'s'} · mapped route`:'No route found — try a nearby landmark or transit stop');};
  const gpsClick=()=>{if(!navigator.geolocation){setError('Geolocation is not supported by this browser.');return}navigator.geolocation.getCurrentPosition(pos=>{setGps({lat:pos.coords.latitude,lon:pos.coords.longitude});setFrom('My current location');setStatus('GPS location captured');},()=>setError('Location permission was not granted.'));};
  const examples=[['Gandhinagar Sector 21','GIFT City'],['Gandhinagar Sector 21','CG Road'],['Kalupur Railway Station','GIFT City'],['Ahmedabad Airport','GIFT City']];
  const interpret=()=>{const n=norm(prompt);let dest='GIFT City',p='fast';for(const x of router.places)if(n.includes(norm(x[0])))dest=x[0];if(/less walk|little walk|minimum walking/.test(n))p='walk';if(/fewest|minimum transfers/.test(n))p='transfer';const tm=prompt.match(/before\s+(\d{1,2})(?::(\d{2}))?/);setTo(dest);setPref(p);setInsight(<><b>Interpreted request</b><br/>Destination: {dest}<br/>Preference: {p==='walk'?'less walking':p==='transfer'?'fewer transfers':'fastest'}{tm?<><br/>Arrival target: {tm[1]}{tm[2]?':'+tm[2]:''}</>:<><br/>Time target not yet used for ranking.</>}<br/><br/><span>Place recognition now understands aliases and common spelling variations.</span></>);};
  return <main className="app"><header className="hero"><div className="brand-wrap"><div className="brand"><div className="brand-mark" aria-hidden="true"><span></span><span></span><b>S</b></div><div><div className="brand-name">SETU</div><div className="brand-tagline">Every connection counts.</div></div></div><div className="eyebrow">Ahmedabad · Gandhinagar · Multimodal mobility</div><h1>One city.<br/><em>One connected journey.</em></h1><p>Plan across <b>Metro + AMTS + BRTS + GTSL</b> from one place. SETU brings the city’s transport networks together so the journey feels like one connected system.</p></div><div className="live-badge"><i></i>Offline timetable engine</div></header>
    {error&&<div className="error">{error}<button onClick={()=>setError('')}>×</button></div>}
    <section className="search-card"><div className="search-grid"><Field label="From" value={from} onChange={setFrom} placeholder="Sector 21, GIFT City, current location" action={gpsClick} suggestions={fromSuggestions} onPick={setFrom}/><Field label="To" value={to} onChange={setTo} placeholder="CG Road, Infocity, Airport" suggestions={toSuggestions} onPick={setTo}/><button className="primary search-button" onClick={()=>run()}>Find best journey <span>→</span></button></div>
      <div className="chips">{examples.map(([a,b])=><button key={a+b} onClick={()=>{setFrom(a);setTo(b);run(a,b,pref)}}>{a.replace('Gandhinagar ','')} → {b}</button>)}</div>
      <div className="preferences"><span>Optimize for</span>{[['fast','Fastest'],['walk','Less walking'],['transfer','Fewer transfers'],['cheap','Lower fare*']].map(([v,l])=><button className={pref===v?'selected':''} key={v} onClick={()=>{setPref(v);if(from&&to)run(from,to,v)}}>{l}</button>)}<small>* Fare comparison is limited by the published prototype dataset.</small></div></section>
    <JourneyMap route={selectedRoute}/>
    <div className="content"><section className="journeys"><div className="section-head"><h2>Recommended journeys</h2><span>{status}</span></div>{!results.length?<div className="empty"><div className="empty-icon">↗</div><b>Start with a journey</b><p>Try one of the examples above. The router considers walking access, route headways, transfers and the supplied Metro timetable structure.</p></div>:results.map((r,i)=><RouteCard key={i} route={r} best={i===0} selected={selected===i} onSelect={()=>setSelected(i)}/>)}</section>
      <aside><div className="assistant"><div className="assistant-kicker">SETU ASSIST · PROTOTYPE</div><h3>Describe your journey</h3><p>Use plain language such as “Reach GIFT City before 9, little walking”.</p><div className="ai-row"><input value={prompt} onChange={e=>setPrompt(e.target.value)} onKeyDown={e=>e.key==='Enter'&&interpret()} placeholder="Reach GIFT City before 9…"/><button onClick={interpret}>Interpret</button></div>{insight&&<div className="insight">{insight}</div>}</div>
        <div className="stats"><Stat n={stats.selectedBusStops||619} t="bus stops"/><Stat n={stats.busEdges||8529} t="bus connections"/><Stat n={stats.metroStops||53} t="Metro stations"/><Stat n="4" t="networks"/></div>
        <div className="boundary"><b>SETU prototype note</b><p>Map visualization now follows the selected route. Place recognition supports aliases, fuzzy spelling and transit-stop suggestions. Route geometry is currently stop-to-stop prototype geometry; true road/rail geometry can be added as a later data layer.</p></div></aside></div>
    <footer>Map tiles © OpenStreetMap contributors. GPS is requested only after user permission. The routing engine remains offline and deterministic.</footer>
  </main>
}
function Field({label,value,onChange,placeholder,action,suggestions,onPick}){const [open,setOpen]=useState(false);const pick=name=>{onPick(name);setOpen(false)};return <label className="field"><span>{label}</span><div className="autocomplete"><input value={value} onChange={e=>{onChange(e.target.value);setOpen(true)}} onFocus={()=>setOpen(true)} onBlur={()=>setTimeout(()=>setOpen(false),120)} placeholder={placeholder}/>{action&&<button type="button" className="gps" onMouseDown={e=>e.preventDefault()} onClick={action} title="Use current location">◎ GPS</button>}{open&&value&&suggestions?.length>0&&<div className="suggestions">{suggestions.map(s=><button key={s.name} type="button" onMouseDown={e=>e.preventDefault()} onClick={()=>pick(s.name)}><b>{s.name}</b><small>{s.category}</small></button>)}</div>}</div></label>}
function RouteCard({route,best,selected,onSelect}){return <article className={'route '+(best?'best ':'')+(selected?'selected-route':'')} onClick={onSelect}><div className="route-top"><div><span className="route-badge">{best?'BEST MATCH':'ALTERNATIVE'}</span><div className="route-time">{fmt(route.total)}</div><div className="route-meta">{route.transfers} transfer{route.transfers===1?'':'s'} · ~{route.walk} min walking · schedule-based</div></div>{best&&<span className="recommended">Recommended</span>}</div><div className="legs">{route.legs.map((l,i)=><div className={`leg ${l.type}`} key={i}><div className="leg-title">{l.label}{l.route&&l.route!=='Metro'&&l.route!=='walk'&&<small> · {l.route}</small>}</div><div className="leg-line">{l.from}</div><div className="leg-time">↓ {fmt(l.mins)}</div><div className="leg-line">{l.to}</div></div>)}</div><div className="route-map-hint">{selected?'Shown on map':'Click to show on map'} ↗</div></article>}
function Stat({n,t}){return <div className="stat"><b>{n}</b><span>{t}</span></div>}
createRoot(document.getElementById('root')).render(<App/>);
