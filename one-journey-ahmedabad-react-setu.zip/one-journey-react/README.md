# SETU — Ahmedabad & Gandhinagar Multimodal Journey Planner

**Every connection counts.**

SETU is a React/Vite prototype for planning multimodal public-transport journeys across Ahmedabad and Gandhinagar using a single journey view.

## Networks

- Metro
- AMTS
- BRTS
- GTSL
- Walking access

## Prototype capabilities

- Multimodal routing over the supplied demo network
- Headway-based wait estimates
- Walking access to/from transit
- Place aliases and fuzzy spelling recognition
- Landmark and locality map layer
- Leaflet/OpenStreetMap journey visualization
- Plain-language journey interpretation via SETU Assist
- Three route alternatives with a recommended option

## Run locally

```bash
npm install
npm run dev
```

Build:

```bash
npm run build
```

## Important prototype notes

- Route geometry is currently straight stop-to-stop prototype geometry rather than real road/rail geometry.
- Landmark coordinates are approximate reference points and are not guaranteed to represent exact entrances.
- The timetable/router data is local demo data; this is not a live transit feed.
- Map tiles are provided by OpenStreetMap contributors.
